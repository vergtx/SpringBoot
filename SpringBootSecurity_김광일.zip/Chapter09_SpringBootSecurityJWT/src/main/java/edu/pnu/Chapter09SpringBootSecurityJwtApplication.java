package edu.pnu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter09SpringBootSecurityJwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(Chapter09SpringBootSecurityJwtApplication.class, args);
	}

}

package edu.pnu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chapter09SpringBootSecurityJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
